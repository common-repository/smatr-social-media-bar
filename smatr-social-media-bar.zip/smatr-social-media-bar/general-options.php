<?php
$plugin_name = "TwitterFacebook";
$options = get_option($plugin_name . "_options");
?>
<link type="text/css" rel="stylesheet" charset="UTF-8" href="<?php echo $this->plugin_dir; ?>/css/forms-style.css"><script type="text/javascript" charset="UTF-8" src="./Form CSS3_files/main.js"></script></head>

<form id="general_optionsForm" name="general_optionsForm" action="" method="post">

    <h1>
        General Settings
    </h1>
    <p>
        <label>Enable Bar?</label>
        <input type="radio" name="enabled" value="true" <?php echo ($options['enabled'] == "true") ? 'checked="checked"' : ''; ?>>Yes
        <input type="radio" name="enabled" value="false" <?php echo ($options['enabled'] == "false") ? 'checked="checked"' : ''; ?>>No

    </p>
    <p>
        <input type="radio" name="enabled_t_f" value="1" <?php echo ($options['enabled_t_f'] == "1" || empty($options['enabled_t_f'])) ? 'checked="checked"' : ''; ?>>
        <label>Enable Both</label>
    </p>
    <p>
        <input type="radio" name="enabled_t_f" value="2" <?php echo ($options['enabled_t_f'] == "2") ? 'checked="checked"' : ''; ?>>
        <label>Only Twitter</label>
    </p>
    <p>
        <input type="radio" name="enabled_t_f" value="3" <?php echo ($options['enabled_t_f'] == "3") ? 'checked="checked"' : ''; ?>>
        <label>Only Facebook</label> 
    </p>
    <input type="submit" name="submit" value="Update Options">
</form>




