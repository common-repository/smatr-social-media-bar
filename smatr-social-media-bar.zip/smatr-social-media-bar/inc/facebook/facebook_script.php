<?php

ini_set('display_errors', 'Off');
set_time_limit(0);
//require_once('facebook.php');

try {
    include_once "facebook.php";
} catch (Exception $o) {
    echo '<pre>';
    print_r($o);
    echo '</pre>';
}
$profile_id = '';
$facebook = new Facebook(array(
            'appId' => $facebook_options['facebook_app_id'],
            'secret' => $facebook_options['facebook_app_secret_code'],
            'cookie' => true,
        ));
if ($facebook_options['facebook_account_type_type'] == 1) {
    $profile_id = $facebook_options['facebook_username'];
} else if ($facebook_options['facebook_account_type_type'] == 2) {
    $profile_id = $facebook_options['facebook_fan_page_id'];
}

$facebook_profile_info = $facebook->api('/' . $profile_id);
//$facebook_profile_info = $facebook->api('/167163636674870');

$fan_page = $facebook->api(array(
            'method' => 'fql.query',
            'query' => "SELECT
                fan_count,
                name,
                pic_small,
                pic_big,
                pic_square,
                pic,
                pic_large,
                page_url,
                type,
                website,
                has_added_app,
                founded,
                company_overview,
                mission,
                products,
                location,
                parking,
                public_transit,
                public_transit
                FROM page WHERE page_id = '" . $facebook_profile_info['id'] . "'"
        ));

///* total fans */
$fb_fans = $fan_page[0]['fan_count'];

///* Fan page name */
$fb_name = $fan_page[0]['name'];

///* pics */
$fb_pic_square = $fan_page[0]['pic_square'];
?>
