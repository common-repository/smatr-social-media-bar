<?php

if ($facebook_options['facebook_account_type_type'] == 1) {
    $facebook_profile_link = 'https://www.facebook.com/' . $facebook_options['facebook_username'];
} else if ($facebook_options['facebook_account_type_type'] == 2) {
    $facebook_profile_link = $facebook_profile_info['link'];
}

if ($show_options['enabled_t_f'] == 1) { // both enabled
    include 'js/both-twitter-facebook.js.php';
} else if ($show_options['enabled_t_f'] == 2) { //only twitter
    include 'js/only-twitter.js.php';
} else if ($show_options['enabled_t_f'] == 3) {//only facebook
    include 'js/only-facebook.js.php';
}
?>

