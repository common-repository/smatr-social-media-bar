<?php
$plugin_name = "TwitterFacebook";
$facebook_options = get_option($plugin_name . "_facebook_options");
?>
<link type="text/css" rel="stylesheet" charset="UTF-8" href="<?php echo $this->plugin_dir; ?>/css/forms-style.css"><script type="text/javascript" charset="UTF-8" src="./Form CSS3_files/main.js"></script></head>

<form id="general_optionsForm" name="general_optionsForm" action="" method="post">
    <h1>
        Facebook Settins
    </h1>
    <p>
        <label>App ID</label>
        <input type="text" id="facebook_app_id" name="facebook_app_id"  size="50" value="<?php
if (isset($facebook_options['facebook_app_id'])) {
    echo $facebook_options['facebook_app_id'];
}
?>" />
    </p>
    <p>
        <label>App Secret Code</label>
        <input type="text" id="facebook_app_secret_code" name="facebook_app_secret_code"  size="50" value="<?php
               if (isset($facebook_options['facebook_app_secret_code'])) {
                   echo $facebook_options['facebook_app_secret_code'];
               }
?>" />
    </p>
    <p>
        <input type="radio" id="facebook_usernameRBtn" name="facebook_account_type_type" value="1"
        <?php
               if (isset($_POST['facebook_account_type_type']) && $_POST['facebook_account_type_type'] == 1) {
                   echo 'checked="checked"';
               } else if (!isset($_POST['facebook_account_type_type']) && isset($facebook_options['facebook_account_type_type']) && $facebook_options['facebook_account_type_type'] == 1) {
                   echo 'checked="checked"';
               }
        ?>  />
        <label>Username</label>
        <input type="text" id="facebook_username" name="facebook_username" size="50" value="<?php
               if (isset($facebook_options['facebook_username'])) {
                   echo $facebook_options['facebook_username'];
               }
        ?>" />

    </p>

    <p>
        <input type="radio" id="facebook_page_id_profile_idRBtn" name="facebook_account_type_type" value="2"
        <?php
               if (isset($_POST['facebook_account_type_type']) && $_POST['facebook_account_type_type'] == 2) {
                   echo 'checked="checked"';
               } else if (!isset($_POST['facebook_account_type_type']) && isset($facebook_options['facebook_account_type_type']) && $facebook_options['facebook_account_type_type'] == 2) {
                   echo 'checked="checked"';
               }
        ?>  />
        <label>Fan Page Id</label>
        <input type="text" id="facebook_fan_page_id" name="facebook_fan_page_id" size="50" value="<?php
               if (isset($facebook_options['facebook_fan_page_id'])) {
                   echo $facebook_options['facebook_fan_page_id'];
               }
        ?>" />
    </p>

    <p>
        <label>Fan Images</label>
        <input type="number" id="facebook_fan_images_count" name="facebook_fan_images_count"  size="50" min="1" max="25" value="<?php
               if (isset($facebook_options['facebook_fan_images_count'])) {
                   echo $facebook_options['facebook_fan_images_count'];
               }
        ?>" />
    </p>

    <input type="submit" name="submit" value="Update Options">
</form>

