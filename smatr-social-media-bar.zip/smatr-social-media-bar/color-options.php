<?php
$plugin_name = "TwitterFacebook";
$color_options = get_option($plugin_name . "_color_options");
?>
<link href="<?php echo $this->plugin_dir; ?>/css/bg-presets.css" rel="stylesheet" />
<link href="<?php echo $this->plugin_dir; ?>/css/color-presets.css" rel="stylesheet" />

<style>

    input[type=submit],
    a.submit{
        background:#ddd;
        background:-moz-linear-gradient(90deg, #0459b7, #08adff); /* Firefox */
        background:-webkit-gradient(linear, left top, left bottom, from(#08adff), to(#0459b7)); /* Webkit */
        border:1px solid #093c75;
        -moz-border-radius:3px;
        -webkit-border-radius:3px;
        -moz-box-shadow:0 1px 0 #fff;
        -webkit-box-shadow:0 1px 0 #fff;
        color:#fff;
        cursor:pointer;
        font-family:Arial,sans-serif;
        font-size:12px;
        font-weight:bold;
        margin-left:120px;
        padding:5px 10px;
        text-decoration:none;
        text-shadow:0 1px 1px #333;
        text-transform:uppercase;
    }
    input[type=submit]:hover,
    a.submit:hover{
        background:#eee;
        background:-moz-linear-gradient(90deg, #067cd3, #0bcdff);
        background:-webkit-gradient(linear, left top, left bottom, from(#0bcdff), to(#067cd3));
        border-color:#093c75;
        text-decoration:none;
    }
    input[type=submit]:active,
    input[type=submit]:focus,
    a.submit:active,
    a.submit:focus{
        background:#ccc;
        background:-moz-linear-gradient(90deg, #0bcdff, #067cd3);
        background:-webkit-gradient(linear, left top, left bottom, from(#067cd3), to(#0bcdff));
        border-color:#093c75;
        outline:none;
    }
    .gradient-control {
        background: none repeat scroll 0 0 #F9F9F9;
        border: 1px solid #EEEEEE;
        font-family: arial;
        padding: 1em;
        position: relative;
        width: 900px;
    }
    .color-control{
        background: none repeat scroll 0 0 #F9F9F9;
        border: 1px solid #EEEEEE;
        display: block;
        float: left;
        font-family: arial;
        padding: 1em;
        position: relative;
        width: 900px;
    }
    .color-control .column {
        float: left;
        margin-left: 20px;
    }

    .color-control .column.right {
        margin-left: 40px;
    }
    .color-control .column {
        float: left;
        margin-left: 20px;
    }

    .gradient-control .column {
        float: left;
        margin-left: 20px;
    }
    .gradient-control .column.right {
        margin-left: 40px;
    }
    .gradient-control .column {
        float: left;
        margin-left: 20px;
    }
    .presets {
        height: 180px;
    }
    .font-presets{        
        height: 205px;
    }
    .color-presets {
        height: 180px;
    }
    .twitter-icon-presets{
        height: 180px;
    }

    .twitter-icon-presets .twitter-icon-presets-container {
        border: 2px inset #DDDDDD;
        height: 115px;
        margin: 30px;
        overflow: auto;
    }

    .twitter-icon-presets .twitter-icon-preset-item {
        border: 0px inset #000000;
        cursor: pointer;
        display: block;
        float: left;
        /*        height: 30px;
                width: 30px;*/
    }
    .presets .presets-container {
        border: 2px inset #DDDDDD;
        height: 115px;
        margin: 30px;
        overflow: auto;
    }
    .presets .preset-item {
        border: 1px inset #000000;
        cursor: pointer;
        display: block;
        float: left;
        height: 30px;
        width: 30px;
    }

    .color-presets .color-presets-container {
        border: 2px inset #DDDDDD;
        height: 115px;
        margin: 30px;
        overflow: auto;
    }
    .color-presets .color-preset-item {
        border: 1px inset #000000;
        cursor: pointer;
        display: block;
        float: left;
        height: 30px;
        width: 30px;
    }

    .font-presets .font-presets-container {
        border: 2px inset #DDDDDD;
        height: 115px;
        margin: 15px;
        overflow: auto;
    }
    .font-presets .font-preset-item {
        border: 1px inset black;
        cursor: pointer;
        display: block;
        float: left;
        height: 25px;
        width: 25px;
        padding-top: 10px;
        font-size: 12px;
        padding-left: 10px;
    }


    .dialog-panel {
        border: 1px solid #999999;
        margin-top: 30px;
        position: relative;
        width: 400px;
        border: solid 1px black;
        border-radius: 8px;
        -webkit-border-radius: 8px;
        -moz-border-radius: 8px;
    }
    .dialog-panel .panel-label {
        background: none repeat scroll 0 0 #F9F9F9;
        left: 0.8em;
        position: absolute;
        top: -1.5em;
        border: solid 1px black;
        border-radius: 8px;
        -webkit-border-radius: 8px;
        -moz-border-radius: 8px;
        padding: 6px;
    }
    .preview #preview-panel {
        border: 1px solid #666666;
        height: 35px;
        margin: 2em;
        max-height: 350px;
        max-width: 355px;
        width: 355px;
        padding-top: 17px;
        text-align: center;
    }

</style>

<script>
    jQuery(document).ready(function() {
        jQuery('.preset-item').live('click', function(e){
            var bg = jQuery(this).attr('id');
            jQuery('div[id=preview-panel]').removeClass();
            jQuery('div[id=preview-panel]').addClass('preset-style-' + bg);
            jQuery('input[id=selected-preset]').val('preset-style-' + bg);
            
        });
        jQuery('.color-preset-item').live('click', function(e){
            var color = jQuery(this).attr('id');
            color_class = color.substr(5);
            color = jQuery(this).css('color');
            jQuery('div[id=preview-panel]').css('color', color);
            jQuery('input[id=selected-text-color-preset]').val('color-preset-style-' + color_class);
        });
        jQuery('.font-preset-item').live('click', function(e){
            var font = jQuery(this).attr('id');
            font_size = font.substr(5);
            jQuery('div[id=preview-panel]').css('font-size', font_size + 'px');
            jQuery('input[id=selected-font-size]').val(font_size + 'px');
        });

    });
</script>
<form id="general_optionsForm" name="general_optionsForm" action="" method="post">
    <div class="gradient-control clearfix" id="gradient-control-1">
        <div class="column left">
            <div class="presets dialog-panel clearfix noselect">
                <div class="panel-label">Bar Background Presets</div>
                <div class="presets-container">
                    <?php
                    for ($i = 1; $i <= 132; $i++) {
                    ?>
                        <div id="<?php echo $i; ?>" class="preset-item  has-preset-contextmenu preset-style-<?php echo $i; ?>"></div>
                    <?php } ?>
                </div>
            </div>
            <div class="color-presets dialog-panel clearfix noselect">
                <div class="panel-label">Text Color Presets</div>
                <div class="color-presets-container">
                    <?php
                    for ($i = 1; $i <= 132; $i++) {
                    ?>
                        <div id="text-<?php echo $i; ?>" class="color-preset-item  has-preset-contextmenu color-preset-bg-style-<?php echo $i; ?> color-preset-style-<?php echo $i; ?>"></div>
                    <?php } ?>
                </div>
            </div>
            <div class="font-presets dialog-panel clearfix">
                <div class="panel-label">Font Size </div>
                <div style="margin: 30px;">

                    <?php
                    for ($i = 8; $i <= 36; $i++) {
                    ?>
                        <div id="font-<?php echo $i; ?>" class="font-preset-item  has-preset-contextmenu "><?php echo $i; ?></div>
                    <?php } ?>
                </div>
            </div>
            <div class="twitter-icon-presets dialog-panel clearfix">
                <div class="panel-label">Twitter Icons</div>
                <div class="twitter-icon-presets-container">
                    <?php
                    for ($i = 1; $i <= 47; $i++) {
                    ?>
                        <div id="twitter-img-<?php echo $i; ?>" class="twitter-icon-preset-item  has-preset-contextmenu ">
                            <input type="radio" name="twitter-icon-preset" value="<?php echo $i; ?>" />
                            <img width="30" src="<?php echo $this->plugin_dir . "/img/twitter/twitter-" . $i . ".png"; ?>" alt=""/>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="column right">
            <div class="preview dialog-panel clearfix">
                <div class="panel-label">Preview</div>
                <div id="preview-panel" class="<?php
                    if (isset($color_options['selected-preset'])) {
                        echo $color_options['selected-preset'] . ' ';
                    }
                    if (isset($color_options['selected-text-color-preset'])) {
                        echo $color_options['selected-text-color-preset'];
                    }
                    ?>"  style="font-size: <?php
                     if (isset($color_options['selected-font-size'])) {
                         echo $color_options['selected-font-size'];
                     }
                    ?>;" >
                    Preview Text
                </div>
                <input type="text" id="selected-preset" name="selected-preset" value="<?php
                     if (isset($color_options['selected-preset'])) {
                         echo $color_options['selected-preset'];
                     }
                    ?>" style="display:none;"/>
                <input type="text" id="selected-text-color-preset" name="selected-text-color-preset" value="<?php
                       if (isset($color_options['selected-text-color-preset'])) {
                           echo $color_options['selected-text-color-preset'];
                       }
                    ?>" style="display:none;"/>
                <input type="text" id="selected-font-size" name="selected-font-size" value="<?php
                       if (isset($color_options['selected-font-size'])) {
                           echo $color_options['selected-font-size'];
                       }
                    ?>" style="display:none;"/>


            </div>
        </div>
    </div>

    <div id="submit-btn" style=" border: 0px solid gray;
         display: block;
         float: left;
         height: 50px;
         position: relative;
         width: 810px;
         padding-top: 20px;">
        <input type="submit" name="submit" value="Update Options">
    </div>

</form>




