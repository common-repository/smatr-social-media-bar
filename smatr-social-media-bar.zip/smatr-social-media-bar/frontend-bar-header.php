<?php
$twitter_options = get_option($this->plugin_name . "_twitter_options");
$facebook_options = get_option($this->plugin_name . "_facebook_options");
$color_options = get_option($this->plugin_name . "_color_options");
$show_options = get_option($this->plugin_name . "_options");
include("inc/facebook/facebook_script.php");
?>

<?php include("css/bar_css.php"); ?>
<link href="<?php echo $this->plugin_dir; ?>/css/bg-presets.css" rel="stylesheet" />
<link href="<?php echo $this->plugin_dir; ?>/css/color-presets.css" rel="stylesheet" />
<link href="<?php echo $this->plugin_dir; ?>/css/twitter.css" rel="stylesheet" />

<script src="<?php echo $this->plugin_dir; ?>/js/jquery.twitter-friends-1.0.min.js" type="text/javascript"></script>

<script type="text/javascript" src="http://static.ak.connect.facebook.com/js/api_lib/v0.4/FeatureLoader.js.php/en_US"></script>
<script type="text/javascript">FB.init("<?php echo $facebook_options['facebook_app_id']; ?>");</script>
<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>

<script type="text/javascript">
    jQuery(document).ready(function() {
<?php include("bar_structure.php"); ?>

        jQuery('body').prepend(html);

        jQuery('#twitter-profile').twitterFriends({
            debug:1,
            username:'<?php echo $twitter_options['twitter_username']; ?>',
            header:'<div id="profile_photo"><a href=\'_tp_\'><img src=\'_ti_\' width="24" height="24"/></a></div>',
            users:0,
            info: ''
        });

        jQuery('#twitter-followers-count').twitterFriends({
            debug:1,
            username:'<?php echo $twitter_options['twitter_username']; ?>',
            header:'<?php echo $twitter_options['twitter_username']; ?> has _fo_ followers',
            users:0,
            info: ''
        });
        jQuery('#twitter-followers').twitterFriends({
            debug:1,
            username:'<?php echo $twitter_options['twitter_username']; ?>',
            users:<?php echo $twitter_options['twitter_followers_images_count']; ?>,
            users_max:<?php echo $twitter_options['twitter_followers_images_count']; ?>,
            user_image:24,
            info: ''
        });
        
        jQuery("div[id=hide_bar_button]").live( 'click', function(){
            jQuery('div#bar-inner').slideUp('slow');
            jQuery("div[id=hide_bar_button]").hide();
            jQuery("div[id=show_bar_button]").show();
        });

        jQuery("div[id=show_bar_button]").live( 'click', function(){
            jQuery('div#bar-inner').slideDown('slow');
            jQuery("div[id=hide_bar_button]").show();
            jQuery("div[id=show_bar_button]").hide();
        });
        
        jQuery('input[type=button][id=follow-btn]').live('click', function(e){
            e.preventDefault();
            var left = (screen.width/2)-(640/2);
            var top = (screen.height/2)-(480/2);
            window.open (
            "http://twitter.com/<?php echo $twitter_options['twitter_username']; ?>",
            "Twitter Follow",
            'toolbar=no, location=yes, directories=no, status=yes, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width=640, height=480 , top='+top+', left='+left);
        });

<?php ?>
    });
</script>

