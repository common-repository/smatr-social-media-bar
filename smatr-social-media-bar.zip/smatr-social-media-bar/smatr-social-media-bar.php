<?php

/*
  Plugin Name: Smatr Social Media Bar
  Description: This plugin can be used to show twitter followers, twitter profile, twitter total no of followers, and twitter follow button, also it can be used to show facebook like button, facebook fans, facebook profile and facebook total fans.
  Version: 0.3
  Author: Smatr Apps
  Author URI: http://www.njmart.in/smatrsmbar
 */

/* If class does not exist, do it */
if (!class_exists('TwitterFacebook')) {

    class TwitterFacebook {
        /* Class variables */

        var $plugin_name;
        var $options_name;
        var $plugin_dir;
        var $displayed;

        /* class constructor */

        public function __construct() {
            $this->plugin_name = "TwitterFacebook";
            $this->options_name = $this->plugin_name . "_options";
            $this->plugin_dir = WP_PLUGIN_URL . '/' . dirname(plugin_basename(__FILE__));
        }

        /* class activation */

        function activate() {
            $default_options = array(
                'enabled' => 'true',
                'displayed' => 'true',
                'enabled_t_f' => '1'
            );

            add_option($this->options_name, $default_options);

            $facebook_options = array(
                'facebook_app_id' => '221193581226413',
                'facebook_app_secret_code' => 'e31ed1365873a5ab9cef0962898421ed',
                'facebook_fan_images_count' => '3',
                'facebook_account_type_type' => '1'
            );

            add_option($this->plugin_name . "_facebook_options", $facebook_options);

            $twitter_options = array(
                'twitter_followers_images_count' => '3'
            );

            add_option($this->plugin_name . "_twitter_options", $twitter_options);

            $color_options = array(
                'selected-preset' => 'preset-style-2',
                'selected-text-color' => '#FFF',
                'selected-font-size' => '12px',
                'twitter-icon-preset' => '1'
            );

            add_option($this->plugin_name . "_color_options", $color_options);
        }

        /* Default Options Page */

        function general_options_menu() {
            if (!current_user_can('manage_options')) {
                wp_die(__('You do not have sufficient permissions to access this page.'));
            }
            if ($_POST['submit']) {
                update_option($this->options_name, $_POST);
                echo 'Successfully Updated';
            }
            include("general-options.php");
        }

        /* Twitter Options Page */

        function twitter_options_menu() {
            if (!current_user_can('manage_options')) {
                wp_die(__('You do not have sufficient permissions to access this page.'));
            }
            if ($_POST['submit']) {
                update_option($this->plugin_name . "_twitter_options", $_POST);
                echo 'Successfully Updated';
            }
            include("twitter-options.php");
        }

        function facebook_options_menu() {
            if (!current_user_can('manage_options')) {
                wp_die(__('You do not have sufficient permissions to access this page.'));
            }
            if ($_POST['submit']) {
                update_option($this->plugin_name . "_facebook_options", $_POST);
                echo 'Successfully Updated';
            }
            include("facebook-options.php");
        }

        function color_options_menu() {
            if (!current_user_can('manage_options')) {
                wp_die(__('You do not have sufficient permissions to access this page.'));
            }
            if ($_POST['submit']) {
                update_option($this->plugin_name . "_color_options", $_POST);
                echo 'Successfully Updated';
            }
            include("color-options.php");
        }

        /* Admin Panel Menu */

        function twitter_facebook_admin_menu() {

            /* Main Menu */
            add_menu_page(
                    $this->plugin_name . " Options",
                    "Smatr Social Media Bar",
                    'manage_options',
                    $this->plugin_name,
                    array(&$this, 'general_options_menu')
            );

            /* Sub Menu Facebook Options */
            add_submenu_page(
                    $this->plugin_name,
                    $this->plugin_name . "Facebook Options",
                    "Facebook Options",
                    'manage_options',
                    $this->plugin_name . "-facebook-options",
                    array(&$this, 'facebook_options_menu')
            );

            /* Sub Menu Twitter Options */
            add_submenu_page(
                    $this->plugin_name,
                    $this->plugin_name . "Twitter Options",
                    "Twitter Options",
                    'manage_options',
                    $this->plugin_name . "-twitter-options",
                    array(&$this, 'twitter_options_menu')
            );

            /* Sub Menu Twitter Options */
            add_submenu_page(
                    $this->plugin_name,
                    $this->plugin_name . "Color Options",
                    "Appearence Options",
                    'manage_options',
                    $this->plugin_name . "-color-options",
                    array(&$this, 'color_options_menu')
            );
        }

        function display_bar($content = '') {
            $options = get_option($this->options_name);

            if ($options['enabled'] == "true") {
                include("frontend-bar-header.php");
            }
        }

//end activation
    }

}

/* if class is not initialized, do it */
if (class_exists('TwitterFacebook')) {
    $saasTwitterFacebook = new TwitterFacebook();
}

/* if class object created register plugin to wordpress */
if (isset($saasTwitterFacebook)) {
    /* loading jquery */
    wp_enqueue_script("jquery");

    /* registring plugin on plugin activation */
    register_activation_hook(__FILE__, array(&$saasTwitterFacebook, 'activate'));

    /* Adding Admin Panel menu for my plugin */
    add_action('admin_menu', array(&$saasTwitterFacebook, 'twitter_facebook_admin_menu'), 1);

    /* Show bar onf ron end */
    add_action('wp_footer', array(&$saasTwitterFacebook, 'display_bar'));
}
?>
