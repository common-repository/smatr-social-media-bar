<?php
$plugin_name = "TwitterFacebook";
$twitter_options = get_option($plugin_name . "_twitter_options");
?>
<link type="text/css" rel="stylesheet" charset="UTF-8" href="<?php echo $this->plugin_dir; ?>/css/forms-style.css"><script type="text/javascript" charset="UTF-8" src="./Form CSS3_files/main.js"></script></head>

<form id="general_optionsForm" name="general_optionsForm" action="" method="post">

    <h1>
        Twitter Settings
    </h1>

    <p>
        <label>Username</label>
        <input type="text" id="twitter_username" name="twitter_username" value="<?php
if (isset($twitter_options['twitter_username'])) {
    echo $twitter_options['twitter_username'];
}
?>" />
    </p>

    <p>
        <label>Followers</label>
        <input type="number" id="twitter_followers_images_count" name="twitter_followers_images_count" min="1" max="30" value="<?php
               if (isset($twitter_options['twitter_followers_images_count'])) {
                   echo $twitter_options['twitter_followers_images_count'];
               }
?>" />
    </p>
    <input type="submit" name="submit" value="Update Options">
</form>

