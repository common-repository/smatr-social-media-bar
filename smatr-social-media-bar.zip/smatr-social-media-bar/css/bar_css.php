<style>
    #bar-main {
        margin: 0 auto;
        min-width: 1024px;
        width: 100%;
        position: fixed;
        display: block;
        font-size: 1em;
        color: #fff;
        z-index: 9999;
    }

    .show_bar{
        width: 14px;
        height: 14px;
        position: absolute;
        top: 7px;
        right: 6px;
    }
    .hide_bar{
        width: 14px;
        height: 14px;
        position: absolute;
        top: 7px;
        right: 6px;
    }
    #bar-inner {
        border: 0px solid #929191;
        height: 28px;
    }
    #bar-logo{
        width: 3%;
        height: 28px;
        display: block;
        float: left;
        position: relative;
        margin-top: 2px;
        margin-left: 3px;
    }
    #bar-seperator-left{
        float: left;
        height: 30px;
        display: block;
        position: relative;
        margin-right: 2px;
        border-right: 1px solid;
        margin-top: 10px;
        margin-bottom: 10px;
    }
    #bar-seperator-middle{
        float: left;
        height: 40px;
        display: block;
        position: relative;
        margin-right: 2px;
        border-right: 1px solid;
        margin-top: 5px;
        margin-bottom: 5px;
    }
    #bar-seperator-right{
        float: left;
        height: 30px;
        display: block;
        position: relative;
        margin-right: 6px;
        border-right: 1px solid;
        margin-top: 10px;
        margin-bottom: 10px;
    }

    .single{
        width: 95% !important;
    }

    #facebook_container{
        border: 0px solid #929191;
        height: 28px;
        width: 48%;
        display: block;
        position: relative;
        float: left;
    }

    #twitter_container{
        border: 0px solid #929191;
        height: 28px;
        width: 48%;
        display: block;
        position: relative;
        float: left;
    }
    #twitter-profile{
        width: 34%;
        display: block;
        float: left;
        overflow: hidden;
        margin-top: 2px;
        margin-right: 0;
    }
    #twitter-follow-btn{
        width: 10%;
        display: block;
        float: left;
        overflow: hidden;
        margin-top: 2px;
        margin-right: 4px;
        text-align: center;
    }
    div.tf-header {
        border: 0px solid silver;
        margin: 0 0 1px;
        overflow: hidden;
        width: 100%;
    }
    #twitter-followers {
        width: 50%;
        float: left;
        position: relative;
        display: block;
        margin-top: 2px;
    }
    #twitter-followers .tf-users a img{
        padding-right: 6px;
    }
    #twitter-followers-count div.tf-header{
        display: block;
        float: left;
        position: relative;
        width: 100%;
        word-wrap: break-word;
    }
    #profile_photo{
        float: left;
        height: 32px;
        position: relative;
        width: 28%;
        margin-right: 0;
    }
    #twitter_social_residence{
        display: block;
        float: left;
        position: relative;
        width: 70%;
        word-wrap: break-word;
    }

    #facebook_social_residence{
        display: block;
        float: left;
        position: relative;
        width: 81%;
        word-wrap: break-word;
    }
    #follow_btn{
        display: block;
        float: left;
        position: relative;        
    }

    #twitter-followers-count{
        float: left;
        width: 34%;
        display: block;
        overflow: hidden;
        margin-top: 1px;
    }
    #facebook_profile_pic{
        float: left;
        height: 32px;
        margin-right: 0;
        position: relative;
        width: 19%;
    }
    #facebook_followers {
        border: 0px solid #929191;
        height: 28px;
        width: 63%;
        display: block;
        position: relative;
        float: left;
    }
    #facebook_followers_total{
        border: 0px solid #929191;
        height: 28px;
        width: 32%;
        display: block;
        position: relative;
        float: left;
        margin-top: 2px;
        margin-left: 5px;
    }
    #facebook_like{
        border: 0px solid #929191;
        height: 28px;
        width: 8%;
        display: block;
        position: relative;
        float: left;
    }

    #facebook_user{
        border: 0px solid #929191;
        height: 28px;
        width: 38%;
        display: block;
        position: relative;
        float: right;
        margin-top: 2px;
    }

</style>