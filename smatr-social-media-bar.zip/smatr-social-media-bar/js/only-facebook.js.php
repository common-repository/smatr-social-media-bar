var html =
	'<div id="bar-main">' +
		'<div id="bar-inner" class="<?php echo $color_options['selected-preset'] . ' ' . $color_options['selected-text-color-preset']; ?>" style="<?php echo 'font-size: ' . $color_options['selected-font-size'] . '; color: ' . $color_options['selected-text-color'] . ';'; ?>">' +
        '<div id="bar-logo">' +
            '<a href="http://www.njmart.in/smatrsmbar">' +
                '<img src="<?php echo $this->plugin_dir; ?>/img/logo.png" alt="Smatr Apps" width="24" height="24"/>' +
                '</a>'+
            '</div>' +
        '<div id="facebook_container" class="single">' +
            '<div id="facebook_followers_total" style="width: 20% !important;">' +
                '<?php echo $fb_fans; ?> people like <?php echo $fb_name; ?>' +
                '</div>' +
            '<div id="facebook_user" style="float:left !important; width:21% !important;">' +
                '<div id="facebook_profile_pic" style="width:32px !important;">' +
                    '<a target="_blank" href="<?php echo $facebook_profile_link; ?>" >' +
                        '<img src="<?php echo $fb_pic_square; ?>" width="24" height="24" />' +
                        '</a>' +
                    '</div>' +
                '<div id="facebook_social_residence">' +
                    '<?php echo $fb_name; ?> on Facebook' +
                    '</div>' +
                '</div>' +
            '<div id="facebook_followers" style="width: 58% !important;">' +
                '<div id="facebox" style="">' +
                    '<fb:fan profile_id="<?php echo $facebook_profile_info['id']; ?>" stream="0" connections="<?php echo trim($facebook_options['facebook_fan_images_count']); ?>" logobar="0" width="704" height="25" css="<?php echo $this->plugin_dir; ?>/css/facebook_style.css?6.1.1"></fb:fan>' +
                    '</div>' +
                '</div>' +
            '</div>' +  
        '</div>' +
    '<div id="hide_bar_button" class="hide_bar">' +
        '<img src="<?php echo $this->plugin_dir; ?>/img/collapse.png" alt="Hide" width="16" height="16"/>' +
        '</div>' +
    '<div id="show_bar_button" class="show_bar" style="display: none;">' +
        '<img src="<?php echo $this->plugin_dir; ?>/img/expand.png" alt="Show" width="16" height="16" />' +
        '</div>' +
    '</div>';