var html =
	'<div id="bar-main">' +
		'<div id="bar-inner" class="<?php echo $color_options['selected-preset'] . ' ' . $color_options['selected-text-color-preset']; ?>" style="<?php echo 'font-size: ' . $color_options['selected-font-size'] . '; color: ' . $color_options['selected-text-color'] . ';'; ?>">' +
        '<div id="bar-logo">' +
            '<a href="http://www.njmart.in/smatrsmbar">' +
                '<img src="<?php echo $this->plugin_dir; ?>/img/logo.png" alt="Smatr Apps" width="24" height="24"/>' +
                '</a>'+
            '</div>' +
        '<div id="facebook_container">' +
            '<div id="facebook_followers">' +
                '<div id="facebox" style="">' +
                    '<fb:fan profile_id="<?php echo $facebook_profile_info['id']; ?>" stream="0" connections="<?php echo trim($facebook_options['facebook_fan_images_count']); ?>" logobar="0" width="383" height="28" css="http://www.xyristechnologies.com/sites/thesisl-newsletter-services/facebook_style.css?6<?php echo $this->plugin_dir; ?>/css/facebook_style.css?0.0.1"></fb:fan>' +
                    '</div>' +
                '</div>' +
            '<div id="facebook_profile_pic" style="width: 24px !important; margin-top: 2px;">' +
                '<a target="_blank" href="<?php echo $facebook_profile_link; ?>" >' +
                    '<img src="<?php echo $fb_pic_square; ?>" width="24" height="24" />' +
                    '</a>' +
                '</div>' +
            '<div id="facebook_followers_total">' +
                '<?php echo $fb_fans; ?> people like <?php echo $fb_name; ?>' +
                '</div>' +
            '</div>' +        
        '<div id="twitter_container">' +
            '<div id="twitter-profile" style="margin-right: 4px; width: 24px !important;">' +
                '</div>' +
            '<div id="twitter-followers-count">' +
                '</div>' +
            '<div id="twitter-follow-btn">' +
                '<a href="http://twitter.com/intent/user?screen_name=<?php echo $twitter_options['twitter_username']; ?>" targer="_blank" title="Follow Me">' +
                    '<img height="24"  alt="Follow Me" src="<?php echo $this->plugin_dir . '/img/twitter/twitter-' . $color_options['twitter-icon-preset'] . '.png'; ?>" />' +
                    '</a>' +
                '</div>' +
            '<div id="twitter-followers">' +
                '</div>' +
            '</div>' +
        '</div>' +
    '<div id="hide_bar_button" class="hide_bar">' +
        '<img src="<?php echo $this->plugin_dir; ?>/img/collapse.png" alt="Hide" width="14" height="14"/>' +
        '</div>' +
    '<div id="show_bar_button" class="show_bar" style="display: none;">' +
        '<img src="<?php echo $this->plugin_dir; ?>/img/expand.png" alt="Show" width="14" height="14" />' +
        '</div>' +
    '</div>'
;