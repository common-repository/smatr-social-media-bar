jQuery(document).ready(function() {    
    jQuery('#twitter-profile-follow-btn').twitterFriends({
        debug:1,
        username:'ladygaga',
        header:'<a href=\'_tp_\'><img src=\'_ti_\'/></a> ladygaga on Twitter!',
        users:0,
        info: ''
    });
});